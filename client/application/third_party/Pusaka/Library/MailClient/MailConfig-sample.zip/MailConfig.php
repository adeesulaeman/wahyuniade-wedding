<?php 
$MailConfig["ServerUrl"] = "http://192.168.8.123:8080/BizlineSoftware/ESS/mailer/server/send.php";