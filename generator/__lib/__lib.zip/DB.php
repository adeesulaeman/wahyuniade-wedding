<?php
namespace Generator;

class DB {

	private $conn;
	private $result;

	function open() {
		$serverName 	= "(local)";
		$connectionInfo = array( "Database"=>"peterpiano", "UID"=>"sa", "PWD"=>"1qaz_2wsx");
		$conn 			= sqlsrv_connect( $serverName, $connectionInfo);
		if( $conn ) {
			$this->conn = $conn;
			//dump("Connection established.");
		}else{
			dump("Connection could not be established.");
			die( print_r( sqlsrv_errors(), true));
		}
	}

	function query($query, $param=[]) {
		$this->result = sqlsrv_query($this->conn, $query, $param);
		return $this->result;
	}

	function rows() {
		$rows 	= [];
		while($row 	= sqlsrv_fetch_array($this->result, SQLSRV_FETCH_ASSOC)) {
			$rows[] = $row;
		}
		return $rows;
	}

	function close() {
		sqlsrv_close($this->conn);
	}

	static function execute_query($query, $param=[]) {
		$serv 	= new DB();
		$serv->open();
		$serv->query($query, $param);
		$rows 	= $serv->rows();
		$serv->close();
		return $rows;
	}

}
