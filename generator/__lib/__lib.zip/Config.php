<?php
function url() {
	return "http://localhost/generator/index.php/";
}
